import random
from turtle import Turtle, Screen

turtle_colors = {"red.gif": "red",
                 "orange.gif": "orange",
                 "pink.gif": "pink",
                 "green.gif": "green",
                 "blue.gif": "blue"}
turtles = []

screen = Screen()
screen.setup(height=600, width=800)
screen.title("Horse Betting")
for key in turtle_colors:
    screen.addshape(key)
bet = screen.textinput(title="Make Your Bet", prompt="Who are you betting on? ")

x = 200
for key in turtle_colors.keys():
    t = Turtle(key)
    t.penup()
    t.goto(-330, x)
    x -= 100
    turtles.append(t)

score = Turtle()
score.color("black")
score.penup()
score.hideturtle()
score.goto(0, 0)

race = True
while race:
    for turtle in turtles:
        turtle.forward(random.randint(0, 30))
        if turtle.xcor() > 335:
            winner = turtle_colors[turtle.shape()]
            if winner == bet:
                score.write("Congrats! You won the bet!", font=("Times", 35, "bold"), align="center")
                race = False
            else:
                score.write("Better luck next time! You lost the bet.", font=("Times", 35, "bold"), align="center")
                race = False

screen.exitonclick()
